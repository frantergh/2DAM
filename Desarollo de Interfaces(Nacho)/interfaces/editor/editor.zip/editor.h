#ifndef EDITOR_H
#define EDITOR_H

#include <QDialog>
#include <QWidget>
#include <QTextEdit>
#include <QMainWindow>
#include <QMenu>
#include <QAction>
#include <QToolBar>
#include <QCloseEvent>

// #include "ui_editor.h"

class Editor : public QMainWindow //, public Ui::Editor
{
    Q_OBJECT

public:
    Editor(QWidget *parent = NULL);

    QTextEdit *editorCentral;
    QMenu *menuArchivo;

    QMenu *menuContectual;
    QAction *accionSalir;
    QAction *accionAbrir;
    QAction *accionGuardar;
    QAction *accionGuardarComo;

    QToolBar *barraHerramientas;

    bool modificado;
    QString ruta;
    bool escribirADisco(QString ruta);
    void hacerMenus();
    void closeEvent(QCloseEvent * );

public slots:
    void slotSalir();
    void slotAbrir();
    bool slotGuardar();
    bool slotGuardarComo();
    void slotModificado();
};

#endif